from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from booking_system.admin_dashboard import dashboard
from django.contrib import admin
from django.urls import path, include
from accounts.views import home  # ou l'app où tu as mis la vue

urlpatterns = [
    path('', home, name='home'),  # <-- Page d’accueil
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),
    path('hotels/', include('hotels.urls')),
    path('cars/', include('cars.urls')),
    path('flights/', include('flights.urls')),
    path('bookings/', include('bookings.urls')),
    path('admin/dashboard/', include('bookings.admin_urls')),  # si défini
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)