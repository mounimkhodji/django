from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render
from django.contrib.auth.models import User
from bookings.models import Booking

@staff_member_required
def dashboard(request):
    users_count = User.objects.count()
    total_revenue = Booking.objects.all().aggregate(total=models.Sum('amount'))['total'] or 0
    by_type = Booking.objects.values('booking_type').annotate(count=models.Count('id'))
    return render(request, "admin/dashboard.html", {
        "users_count": users_count,
        "total_revenue": total_revenue,
        "by_type": by_type
    })