from django.contrib import admin
from .models import Flight
from django.utils.html import format_html
from django.urls import path
from django.shortcuts import redirect
from django.contrib import messages
from django.utils import timezone
import random

@admin.register(Flight)
class FlightAdmin(admin.ModelAdmin):
    list_display = ("code", "origin", "destination", "departure", "arrival", "price", "seats")
    search_fields = ("code", "origin", "destination")
    actions = ["generate_random_flights"]

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('generate_random_flights/', self.admin_site.admin_view(self.generate_random_flights_view), name='generate_random_flights'),
        ]
        return custom_urls + urls

    def generate_random_flights(self, request, queryset):
        self._generate_flights(10)
        self.message_user(request, "10 vols générés aléatoirement.")
    generate_random_flights.short_description = "Générer 10 vols aléatoires"

    def generate_random_flights_view(self, request):
        self._generate_flights(10)
        self.message_user(request, "10 vols générés via bouton admin.")
        return redirect("/admin/flights/flight/")

    def _generate_flights(self, n):
        cities = ["Paris", "Londres", "Rome", "Berlin", "Madrid", "Lisbonne", "Amsterdam", "Bruxelles"]
        for _ in range(n):
            origin, destination = random.sample(cities, 2)
            code = f"AF{random.randint(100,999)}"
            departure = timezone.now() + timezone.timedelta(days=random.randint(1, 30), hours=random.randint(0,12))
            arrival = departure + timezone.timedelta(hours=random.randint(1, 5))
            price = random.randint(80, 400)
            seats = random.randint(60, 200)
            Flight.objects.create(
                code=code,
                origin=origin,
                destination=destination,
                departure=departure,
                arrival=arrival,
                price=price,
                seats=seats,
            )