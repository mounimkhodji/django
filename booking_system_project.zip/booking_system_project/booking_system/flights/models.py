from django.db import models

class Flight(models.Model):
    code = models.CharField(max_length=10)
    origin = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    departure = models.DateTimeField()
    arrival = models.DateTimeField()
    price = models.DecimalField(max_digits=8, decimal_places=2)
    seats = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.code}: {self.origin} → {self.destination} ({self.departure.strftime('%d/%m/%Y %H:%M')})"