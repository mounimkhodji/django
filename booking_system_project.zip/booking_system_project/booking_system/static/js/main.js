// Sauvegarder le nom d'utilisateur pour affichage rapide
function saveUsername(username) {
    localStorage.setItem("username", username);
}
// Récupérer le nom d'utilisateur
function getUsername() {
    return localStorage.getItem("username");
}
// Sauvegarder le dernier type de réservation consulté
function saveLastBookingType(type) {
    localStorage.setItem("last_booking_type", type);
}
function getLastBookingType() {
    return localStorage.getItem("last_booking_type");
}
// Sauvegarder temporairement un formulaire (par son id)
function saveFormDraft(formId) {
    const form = document.getElementById(formId);
    if (form) {
        localStorage.setItem(formId + "_draft", JSON.stringify(Object.fromEntries(new FormData(form))));
    }
}
// Récupérer un brouillon de formulaire
function loadFormDraft(formId) {
    const draft = localStorage.getItem(formId + "_draft");
    if (draft) {
        const data = JSON.parse(draft);
        for (let key in data) {
            if (formId && document.getElementById(formId)[key])
                document.getElementById(formId)[key].value = data[key];
        }
    }
}