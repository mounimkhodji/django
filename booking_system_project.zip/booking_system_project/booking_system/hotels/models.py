from django.db import models

class Hotel(models.Model):
    name = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    price_per_night = models.DecimalField(max_digits=8, decimal_places=2)
    capacity = models.PositiveIntegerField()
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to="hotels/", blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.city})"