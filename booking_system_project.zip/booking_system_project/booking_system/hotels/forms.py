from django import forms
from .models import Hotel

class HotelForm(forms.ModelForm):
    class Meta:
        model = Hotel
        fields = ["name", "city", "price_per_night", "capacity", "description", "image"]