from django.test import TestCase

# Créez vos tests ici