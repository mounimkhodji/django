from django.db import models
from django.contrib.auth.models import User

class Booking(models.Model):
    BOOKING_TYPE_CHOICES = [
        ("hotel", "Hôtel"),
        ("car", "Voiture"),
        ("flight", "Vol"),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="bookings")
    booking_type = models.CharField(max_length=10, choices=BOOKING_TYPE_CHOICES)
    object_id = models.PositiveIntegerField()  # id de l'objet réservé (hotel, car, flight)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.booking_type} - {self.amount} €"